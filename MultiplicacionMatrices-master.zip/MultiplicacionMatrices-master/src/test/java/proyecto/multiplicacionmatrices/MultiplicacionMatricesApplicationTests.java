package proyecto.multiplicacionmatrices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiplicacionMatricesApplicationTests {

    @Test
    void contextLoads() {
    }

}

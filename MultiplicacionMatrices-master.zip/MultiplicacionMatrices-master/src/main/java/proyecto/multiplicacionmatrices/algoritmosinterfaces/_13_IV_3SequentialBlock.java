package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _13_IV_3SequentialBlock {
    void algoritmoSequentialBlockDos(double[][]matrizA,double[][]matrizB,int size,int bsize);
}

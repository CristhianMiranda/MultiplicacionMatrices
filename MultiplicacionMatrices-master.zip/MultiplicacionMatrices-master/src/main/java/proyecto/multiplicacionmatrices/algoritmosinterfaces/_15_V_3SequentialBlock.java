package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _15_V_3SequentialBlock {
    void algoritmoSequentialBlockTres(double[][]matrizA,double[][]matrizB,int size,int bsize);
}

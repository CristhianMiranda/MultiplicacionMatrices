package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _11_III_3SequentialBlock {
    void algoritmoSequentialBlock(double[][]matrizA,double[][]matrizB,int size,int bsize);
}

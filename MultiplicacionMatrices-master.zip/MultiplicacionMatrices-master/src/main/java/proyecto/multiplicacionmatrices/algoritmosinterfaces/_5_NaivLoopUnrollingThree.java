package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _5_NaivLoopUnrollingThree {
    void algoritmoNaivLoopUnrollingThree(double[][] matrizA, double[][] matrizB, double[][] matrizC, int N, int P, int M);
}

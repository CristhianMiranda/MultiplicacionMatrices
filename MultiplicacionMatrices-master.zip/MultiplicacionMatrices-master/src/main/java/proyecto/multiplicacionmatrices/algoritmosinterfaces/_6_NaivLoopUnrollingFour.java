package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _6_NaivLoopUnrollingFour {
    void algoritmoNaivLoopUnrollingFour(double[][] A, double[][] B, double[][] Result, int N, int P, int M);
}

package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _16_V_4ParallelBlock {
    void algoritmoParallelBlockTres (double[][]matrizA,double[][]matrizB,int size,int bsize);
}

package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _7_WinogradOriginal {
    void algoritmoWinogradOriginal(double[][] A, double[][] B, double[][] Result, int N, int P, int M);
}

package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _12_III_4ParallelBlock {
    void algoritmoParallelBlock (double[][]matrizA,double[][]matrizB,int size,int bsize);
}

package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _10_StrassenWinograd {
    void algoritmoStrassenWinograd(double[][] matrizA, double[][] matrizB, double[][] matrizC, int N, int P, int M);
}

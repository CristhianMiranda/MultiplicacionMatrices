package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _1_NaivStandard {
    void algoritmoNaivStandard(double[][] matrizA,double[][] matrizB,double[][] matrizC,int n, int p, int m);
}

package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _8_WinogradScaled {
    void algoritmoWinogradScaled(double[][] A, double[][] B, double[][] Result, int N, int P, int M);
}

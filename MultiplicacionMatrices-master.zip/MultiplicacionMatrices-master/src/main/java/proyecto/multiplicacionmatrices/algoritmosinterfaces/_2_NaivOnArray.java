package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _2_NaivOnArray {
    void algoritmoNaivOnArray(double[][] matrizA, double[][] matrizB, double[][] matrizC, int N, int P , int M);
}

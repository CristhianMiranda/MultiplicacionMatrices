package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _9_StrassenNaiv {
    void algoritmoStrassenNaiv(double[][] matrizA, double[][] matrizB, double[][] matrizC, int N, int P, int M);
}

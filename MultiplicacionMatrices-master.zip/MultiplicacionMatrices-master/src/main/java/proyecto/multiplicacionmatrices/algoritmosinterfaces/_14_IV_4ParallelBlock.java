package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _14_IV_4ParallelBlock {
    void algoritmoParallelBlockDos (double[][]matrizA,double[][]matrizB,int size,int bsize);
}

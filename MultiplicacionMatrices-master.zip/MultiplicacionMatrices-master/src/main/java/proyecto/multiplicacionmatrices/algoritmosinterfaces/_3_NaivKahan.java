package proyecto.multiplicacionmatrices.algoritmosinterfaces;

public interface _3_NaivKahan {
    void algoritmoNaivKhan(double[][] matrizA, double[][] matrizB, double[][] matrizC, int N, int P, int M);
}

package proyecto.multiplicacionmatrices.clases;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.CategoryDataset;

import javax.swing.*;
import java.awt.*;

public class Graficador extends JFrame {
    /*
    public void contruirDiagramaBarras() {
        super("Diagrama de Barras De TE(ns)");

        CategoryDataset dataset = createDataset();
        JFreeChart chart = createChart(dataset);

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(500, 350));

        setContentPane(chartPanel);
    }*/
}
